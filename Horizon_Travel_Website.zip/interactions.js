/**
 * HORIZON — Interactions & Reactive Motion Engine
 * Handles magnetic pull, 3D card tilt, spotlight tracking, particle bursts,
 * page-turn curtain transitions, and smooth scroll chapter tracking.
 */

(function () {
  'use strict';

  const isFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. Scroll Progress Bar & Chapter Tracking
     ------------------------------------------------------------------------ */
  const progressBar = document.querySelector('.scroll-progress-line');
  const chapters = Array.from(document.querySelectorAll('.chapter'));
  const railDots = Array.from(document.querySelectorAll('.rail-dot'));
  const railFill = document.querySelector('.rail-fill');
  const navLinks = Array.from(document.querySelectorAll('.nav-link-item a'));
  const navPill = document.querySelector('.nav-pill-backdrop');

  function updateScrollState() {
    const scrollY = window.scrollY;
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    const progress = maxScroll > 0 ? scrollY / maxScroll : 0;

    // Top progress line
    if (progressBar) {
      progressBar.style.transform = `scaleX(${progress})`;
    }

    // Side rail fill
    if (railFill) {
      railFill.style.height = `${progress * 100}%`;
    }

    // Detect currently visible chapter
    let currentChapterIndex = 0;
    const viewportMiddle = scrollY + window.innerHeight * 0.45;

    chapters.forEach((chapter, index) => {
      const top = chapter.offsetTop;
      const height = chapter.offsetHeight;
      if (viewportMiddle >= top && viewportMiddle < top + height) {
        currentChapterIndex = index;
      }
    });

    // Update side rail active dot
    railDots.forEach((dot, idx) => {
      dot.classList.toggle('is-active', idx === currentChapterIndex);
    });

    // Update main nav active link & sliding pill
    const activeChapterId = chapters[currentChapterIndex]?.id;
    if (activeChapterId) {
      navLinks.forEach((link) => {
        const href = link.getAttribute('href');
        const isActive = href === `#${activeChapterId}`;
        link.classList.toggle('active', isActive);

        if (isActive && navPill && isFinePointer) {
          const parent = link.parentElement;
          navPill.style.left = `${parent.offsetLeft + 4}px`;
          navPill.style.width = `${parent.offsetWidth - 8}px`;
        }
      });
    }
  }

  window.addEventListener('scroll', updateScrollState, { passive: true });
  window.addEventListener('resize', updateScrollState);

  /* ------------------------------------------------------------------------
     2. Cinematic Page-to-Page Curtain Transition
     ------------------------------------------------------------------------ */
  const curtain = document.querySelector('.page-transition-curtain');
  const curtainTitle = document.querySelector('.curtain-title');
  const curtainSub = document.querySelector('.curtain-sub');
  let isNavigating = false;

  const chapterNames = {
    'chapter-hero': { num: '01 / DISCOVERY', name: 'Infinite Horizons' },
    'chapter-atlas': { num: '02 / ATLAS', name: 'Curated Destinations' },
    'chapter-architect': { num: '03 / ARCHITECT', name: 'Smart Trip Planner' },
    'chapter-chronicles': { num: '04 / CHRONICLES', name: 'Field Notes & FAQ' },
    'chapter-departure': { num: '05 / DEPARTURE', name: 'Next Flight' }
  };

  async function navigateToChapter(targetId, withCurtain = true) {
    const targetElement = document.getElementById(targetId);
    if (!targetElement || isNavigating) return;

    if (isReducedMotion || !withCurtain || !curtain) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    isNavigating = true;
    const meta = chapterNames[targetId] || { num: 'EXPLORE', name: 'Horizon' };

    if (curtainSub) curtainSub.textContent = meta.num;
    if (curtainTitle) curtainTitle.textContent = meta.name;

    // Curtain slides up to cover screen
    curtain.className = 'page-transition-curtain cover';
    await new Promise((r) => setTimeout(r, 600));

    // Instantly jump position behind the curtain
    targetElement.scrollIntoView({ behavior: 'auto' });
    updateScrollState();
    await new Promise((r) => setTimeout(r, 120));

    // Curtain slides up and out
    curtain.className = 'page-transition-curtain leave';
    await new Promise((r) => setTimeout(r, 650));

    // Reset curtain position silently below the screen
    curtain.className = 'page-transition-curtain';
    isNavigating = false;
  }

  window.navigateToChapter = navigateToChapter;

  // Intercept anchor clicks to use smooth curtain transition
  document.addEventListener('click', (e) => {
    const anchor = e.target.closest('a[href^="#chapter-"]');
    if (!anchor) return;
    const targetId = anchor.getAttribute('href').replace('#', '');
    if (document.getElementById(targetId)) {
      e.preventDefault();
      navigateToChapter(targetId, true);
    }
  });

  // Rail dots click
  railDots.forEach((dot) => {
    dot.addEventListener('click', () => {
      const targetId = dot.dataset.target;
      if (targetId) navigateToChapter(targetId, true);
    });
  });

  /* ------------------------------------------------------------------------
     3. Magnetic Buttons Elastic Tracking
     ------------------------------------------------------------------------ */
  if (isFinePointer && !isReducedMotion) {
    const magneticElements = document.querySelectorAll('.magnetic-target, .btn-primary, .btn-dark, .icon-action-btn');

    magneticElements.forEach((el) => {
      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const deltaX = (e.clientX - centerX) * 0.28;
        const deltaY = (e.clientY - centerY) * 0.35;
        el.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
      });

      el.addEventListener('mouseleave', () => {
        el.style.transform = 'translate(0px, 0px)';
      });
    });
  }

  /* ------------------------------------------------------------------------
     4. Dynamic Ink Ripple Effect on Click
     ------------------------------------------------------------------------ */
  function createRipple(e, target) {
    const rect = target.getBoundingClientRect();
    const ripple = document.createElement('span');
    ripple.className = 'ripple-effect';
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;

    target.appendChild(ripple);
    setTimeout(() => ripple.remove(), 700);
  }

  document.addEventListener('click', (e) => {
    const button = e.target.closest('.btn, .category-tab-btn, .quick-chip, .dest-card-inspect-btn');
    if (button) {
      createRipple(e, button);
    }
  });

  /* ------------------------------------------------------------------------
     5. Confetti / Particle Spark Burst
     ------------------------------------------------------------------------ */
  const sparkColors = ['#2563eb', '#06b6d4', '#10b981', '#f59e0b', '#ffffff'];

  function burstSparks(x, y, count = 18) {
    if (isReducedMotion) return;

    for (let i = 0; i < count; i++) {
      const spark = document.createElement('span');
      spark.className = 'spark-particle';
      spark.style.left = `${x}px`;
      spark.style.top = `${y}px`;
      spark.style.background = sparkColors[Math.floor(Math.random() * sparkColors.length)];
      document.body.appendChild(spark);

      const angle = Math.random() * Math.PI * 2;
      const velocity = 35 + Math.random() * 85;
      const destX = Math.cos(angle) * velocity;
      const destY = Math.sin(angle) * velocity + 20;

      const animation = spark.animate(
        [
          { transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
          { transform: `translate(calc(-50% + ${destX}px), calc(-50% + ${destY}px)) scale(0)`, opacity: 0 }
        ],
        {
          duration: 550 + Math.random() * 400,
          easing: 'cubic-bezier(0.12, 0.8, 0.32, 1)'
        }
      );

      animation.onfinish = () => spark.remove();
    }
  }

  window.burstSparks = burstSparks;

  /* ------------------------------------------------------------------------
     6. Dynamic Spotlight & 3D Card Tilt
     ------------------------------------------------------------------------ */
  function setupReactiveCards() {
    if (!isFinePointer || isReducedMotion) return;

    const cards = document.querySelectorAll('.spotlight-card, .dest-card, .architect-form-card, .architect-preview-card');

    cards.forEach((card) => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        card.style.setProperty('--mouse-x', `${x}px`);
        card.style.setProperty('--mouse-y', `${y}px`);

        // Subtle 3D tilt for destination cards
        if (card.classList.contains('dest-card')) {
          const normX = (x / rect.width - 0.5) * 2; // -1 to 1
          const normY = (y / rect.height - 0.5) * 2; // -1 to 1
          const tiltX = -normY * 6; // max 6 deg
          const tiltY = normX * 6;
          card.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) translateY(-8px)`;
        }
      });

      card.addEventListener('mouseleave', () => {
        if (card.classList.contains('dest-card')) {
          card.style.transform = '';
        }
      });
    });
  }

  window.setupReactiveCards = setupReactiveCards;

  /* ------------------------------------------------------------------------
     7. Custom Cursor Follower
     ------------------------------------------------------------------------ */
  const cursorDot = document.querySelector('.custom-cursor-dot');
  const cursorRing = document.querySelector('.custom-cursor-ring');

  if (cursorDot && cursorRing && isFinePointer && !isReducedMotion) {
    let mouseX = -100;
    let mouseY = -100;
    let ringX = -100;
    let ringY = -100;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.left = `${mouseX}px`;
      cursorDot.style.top = `${mouseY}px`;
    });

    function renderCursor() {
      // Smooth lerp for outer ring
      ringX += (mouseX - ringX) * 0.18;
      ringY += (mouseY - ringY) * 0.18;
      cursorRing.style.left = `${ringX}px`;
      cursorRing.style.top = `${ringY}px`;
      requestAnimationFrame(renderCursor);
    }
    requestAnimationFrame(renderCursor);

    // Expand cursor ring on clickable elements
    const interactiveSelectors = 'a, button, input, select, textarea, .dest-card, .quick-chip, .rail-dot';
    document.addEventListener('mouseover', (e) => {
      if (e.target.closest(interactiveSelectors)) {
        cursorRing.classList.add('is-hovering');
      }
    });

    document.addEventListener('mouseout', (e) => {
      if (e.target.closest(interactiveSelectors)) {
        cursorRing.classList.remove('is-hovering');
      }
    });
  }

  /* ------------------------------------------------------------------------
     8. Scroll Reveal Observer
     ------------------------------------------------------------------------ */
  const revealElements = document.querySelectorAll('.reveal-item');

  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-revealed');
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );

    revealElements.forEach((el) => revealObserver.observe(el));
  } else {
    revealElements.forEach((el) => el.classList.add('is-revealed'));
  }

  // Initialize once DOM is ready
  function init() {
    updateScrollState();
    setupReactiveCards();
    setTimeout(() => {
      document.querySelectorAll('#chapter-hero .reveal-item').forEach((el) => el.classList.add('is-revealed'));
    }, 60);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
