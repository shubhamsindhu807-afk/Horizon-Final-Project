# HORIZON — Interactive Travel Discovery & Trip Planning Platform
### Web Technologies Capstone Project

A modern, highly reactive single-page web application built with vanilla HTML5, CSS3, and JavaScript. The project demonstrates advanced front-end engineering techniques including scroll-driven animations, 3D physics-based micro-interactions, asynchronous state management, and real-time audio synthesis.

---

## Technical Highlights & Features

### 1. Distinct Page-to-Page Scroll & Curtain Transitions
- **Cinematic Chapter Transitions:** Seamless section transitions utilizing an animated curved veil that announces incoming chapters (`01 / DISCOVERY`, `02 / ATLAS`, `03 / ARCHITECT`, `04 / CHRONICLES`, `05 / DEPARTURE`).
- **Floating Side Chapter Rail:** A reactive vertical track monitoring scroll depth with smooth height interpolation, active state indicators, and floating tooltip navigation.
- **Top Scroll Progress Line:** An animated gradient progress indicator tracking page scroll percentage.
- **Scroll-Driven Elevation & Stagger:** Content elements enter viewport dynamically using the `IntersectionObserver` API with orchestrated stagger delays.

### 2. Hyper-Reactive Micro-Interactions & Physics
- **Magnetic Cursor Attraction:** Interactive buttons and navigation controls calculate cursor proximity and translate elastically toward the pointer with spring damping.
- **Real-Time Cursor Spotlight:** Interactive cards track mouse coordinates (`--mouse-x`, `--mouse-y`) to render a continuous specular illumination field.
- **3D Card Perspective Tilt:** Dynamic 3D rotation (`perspective(1000px) rotateX(...) rotateY(...)`) simulating realistic physical card manipulation on hover.
- **Dynamic Ink Ripples:** Custom click waves propagating radially from pointer coordinates.
- **Action Confetti / Particle Sparks:** Physics-based micro-particle bursts rendered when saving places, filtering categories, or saving trip snapshots.
- **Sliding Indicator Pills:** Smooth sliding highlight bars tracking active category tabs and navigation items.

### 3. Curated Global Destinations Database
An extensive collection of 12 global escapes featuring high-resolution photography, climate telemetry, and geographic coordinates:
1. **Kyoto, Japan** — Ancient Tranquility & Zen Heritage
2. **The Dolomites, Italy** — Alps of Fire & Starlit Peaks
3. **Amalfi Coast, Italy** — Cliffside Pastel & Cobalt Seas
4. **Bali & Ubud, Indonesia** — Emerald Terraces & Tropical Solace
5. **Torres del Paine, Patagonia** — Glacial Giants at the End of the Earth
6. **Santorini, Greece** — Chalk-White Calderas & Sun-Drenched Aegean
7. **Reykjavik & Aurora, Iceland** — Cascading Ice & Dancing Northern Lights
8. **Banff & Lake Louise, Canada** — Turquoise Glacial Waters & Rocky Mountains
9. **Serengeti & Ngorongoro, Tanzania** — The Great Migration & Golden Savannas
10. **Marrakech, Morocco** — Ochre Palaces, Secret Riads & Spice Alleys
11. **Ha Long Bay, Vietnam** — Mystic Karsts & Emerald Seaways
12. **Zermatt & Matterhorn, Switzerland** — Crown of the Alps & Alpine Luxury

### 4. Interactive Application Modules
- **Smart Discovery Search Dock:** Real-time query input with instant category suggestions and live card filtering.
- **Destination Telemetry Modal:** Comprehensive modal sheet displaying seasonal recommendations, average temperatures, coordinates, and curated signature experiences.
- **Interactive Trip Architect:** Algorithmic cost estimator featuring live duration sliders (2–21 days), traveler counts, and travel style multipliers (*Balanced*, *Luxury & Boutique*, *Nomad / Backpacker*).
- **Persistent Wishlist Drawer:** Slide-out drawer tracking saved destinations in `localStorage` with a live badge counter and one-click export into the trip builder.
- **Ambient Nature Audio Synthesizer:** Real-time pink-noise ocean wave synthesizer built using the native Web Audio API (zero external audio dependencies).
- **Dynamic Light & Dark Theme:** Persistent CSS custom properties system respecting system preferences and manual toggles.

---

## Project Structure
```text
horizon-travel/
├── index.html            # Main semantic markup & chapter structure
├── styles.css            # Custom design tokens, glassmorphism, responsive grid
├── motion.css            # Transitions, magnetic physics, and 3D tilts
├── destinations-data.js  # Curated destination dataset
├── interactions.js       # Mouse tracking, cursor physics, curtain wipe engine
├── app.js               # Application state, filtering, Web Audio, and storage
└── README.md             # Project documentation
```

## How to Run
1. Open [`index.html`](index.html) in any modern web browser (Edge, Chrome, Firefox, Safari).
2. Alternatively, serve with VS Code Live Server or Python HTTP server:
   ```bash
   python -m http.server 8000
   ```
   and navigate to `http://localhost:8000`.
