/**
 * HORIZON — Application Logic & State Engine
 * Destination Explorer, Saved Wishlist Drawer, Destination Inspection Modal,
 * Live Trip Architect Estimator, Ambient Nature Sound Synthesizer, and Theme Toggle.
 */

function initApp() {
  'use strict';

  /* ------------------------------------------------------------------------
     1. State & Storage
     ------------------------------------------------------------------------ */
  const STORAGE_KEY_SAVED = 'horizon_saved_destinations';
  const STORAGE_KEY_TRIPS = 'horizon_saved_trips';
  const STORAGE_KEY_THEME = 'horizon_theme';

  let savedDestinations = JSON.parse(localStorage.getItem(STORAGE_KEY_SAVED) || '[]');
  let currentCategory = 'all';
  let searchQuery = '';
  let currentSort = 'featured';

  /* ------------------------------------------------------------------------
     2. Theme Management
     ------------------------------------------------------------------------ */
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const storedTheme = localStorage.getItem(STORAGE_KEY_THEME);
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY_THEME, theme);
    if (themeToggleBtn) {
      themeToggleBtn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
      themeToggleBtn.innerHTML = theme === 'dark'
        ? `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>`
        : `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
    }
  }

  const initialTheme = storedTheme || (systemPrefersDark ? 'dark' : 'light');
  applyTheme(initialTheme);

  themeToggleBtn?.addEventListener('click', (e) => {
    const active = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(active);
    if (window.burstSparks) {
      window.burstSparks(e.clientX, e.clientY, 10);
    }
  });

  /* ------------------------------------------------------------------------
     3. Toast Notifications
     ------------------------------------------------------------------------ */
  const toastEl = document.getElementById('toastNotice');
  let toastTimer = null;

  function showToast(message, icon = '✦') {
    if (!toastEl) return;
    clearTimeout(toastTimer);
    toastEl.innerHTML = `<span style="color:var(--g-blue);font-weight:bold;">${icon}</span> <span>${message}</span>`;
    toastEl.classList.add('is-visible');
    toastTimer = setTimeout(() => {
      toastEl.classList.remove('is-visible');
    }, 2800);
  }

  /* ------------------------------------------------------------------------
     4. Ambient Nature Audio Synthesizer (Web Audio API - No External Files)
     ------------------------------------------------------------------------ */
  const ambientAudioBtn = document.getElementById('ambientAudioBtn');
  let audioCtx = null;
  let isPlayingAmbient = false;
  let oceanNode = null;
  let gainNode = null;

  function initOceanSynth() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioContext();

      // Buffer with pink noise (relaxing ocean/wind sound)
      const bufferSize = audioCtx.sampleRate * 4;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.08;
        b6 = white * 0.115926;
      }

      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;

      // Gentle lowpass filter with slow wave LFO
      const filter = audioCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(380, audioCtx.currentTime);

      const lfo = audioCtx.createOscillator();
      lfo.frequency.setValueAtTime(0.12, audioCtx.currentTime); // ~8 sec ocean swell
      const lfoGain = audioCtx.createGain();
      lfoGain.gain.setValueAtTime(260, audioCtx.currentTime);
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start();

      gainNode = audioCtx.createGain();
      gainNode.gain.setValueAtTime(0.01, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.35, audioCtx.currentTime + 2);

      noise.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      noise.start();

      oceanNode = noise;
    } catch (err) {
      console.warn('Web Audio Ambient initialization prevented:', err);
    }
  }

  ambientAudioBtn?.addEventListener('click', () => {
    if (!audioCtx) {
      initOceanSynth();
      isPlayingAmbient = true;
    } else if (audioCtx.state === 'suspended') {
      audioCtx.resume();
      isPlayingAmbient = true;
    } else if (isPlayingAmbient) {
      gainNode?.gain.setValueAtTime(0.001, audioCtx.currentTime);
      audioCtx.suspend();
      isPlayingAmbient = false;
    } else {
      audioCtx.resume();
      gainNode?.gain.setValueAtTime(0.35, audioCtx.currentTime);
      isPlayingAmbient = true;
    }

    ambientAudioBtn.classList.toggle('sound-playing', isPlayingAmbient);
    showToast(isPlayingAmbient ? 'Playing ambient nature soundscape' : 'Ambient soundscape paused', '♫');
  });

  /* ------------------------------------------------------------------------
     5. Destination Explorer (Render, Filter, Search, Sort)
     ------------------------------------------------------------------------ */
  const destinationsGrid = document.getElementById('destinationsGrid');
  const destinationSearchInput = document.getElementById('destinationSearchInput');
  const sortSelect = document.getElementById('sortDestinations');
  const categoryTabs = Array.from(document.querySelectorAll('.category-tab-btn'));
  const categoryTabPill = document.querySelector('.category-tab-pill');

  function renderDestinations() {
    if (!destinationsGrid || typeof DESTINATIONS === 'undefined') return;

    // Filter logic
    let filtered = DESTINATIONS.filter((item) => {
      const matchCategory = currentCategory === 'all' || item.category.toLowerCase() === currentCategory.toLowerCase();
      const query = searchQuery.trim().toLowerCase();
      const matchSearch =
        !query ||
        item.name.toLowerCase().includes(query) ||
        item.country.toLowerCase().includes(query) ||
        item.region.toLowerCase().includes(query) ||
        item.vibe.toLowerCase().includes(query) ||
        item.tags.some((t) => t.toLowerCase().includes(query));
      return matchCategory && matchSearch;
    });

    // Sort logic
    if (currentSort === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    } else if (currentSort === 'budget') {
      filtered.sort((a, b) => a.dailyBudget - b.dailyBudget);
    } else if (currentSort === 'alpha') {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    }

    if (filtered.length === 0) {
      destinationsGrid.innerHTML = `
        <div class="destinations-empty-state">
          <h3>No matching destinations found</h3>
          <p>Try searching for a different vibe (e.g. "Culture", "Summer", "Adventure") or clear your filters.</p>
          <button class="btn btn-outline btn-sm" id="resetFiltersBtn" style="margin-top:1rem;">Reset Filters</button>
        </div>
      `;
      document.getElementById('resetFiltersBtn')?.addEventListener('click', () => {
        currentCategory = 'all';
        searchQuery = '';
        if (destinationSearchInput) destinationSearchInput.value = '';
        updateCategoryPill();
        renderDestinations();
      });
      return;
    }

    // Build Cards HTML
    destinationsGrid.innerHTML = filtered
      .map((dest) => {
        const isSaved = savedDestinations.includes(dest.id);
        return `
        <article class="dest-card spotlight-card" data-id="${dest.id}">
          <div class="dest-card-media">
            <img src="${dest.image}" alt="${dest.name}, ${dest.country}" loading="lazy" />
            <div class="dest-card-overlay"></div>
            <span class="dest-card-badge">${dest.badge}</span>
            <button class="dest-card-save-btn ${isSaved ? 'is-saved' : ''}" data-save-id="${dest.id}" aria-label="Save ${dest.name} to wishlist">
              ${isSaved ? '♥' : '♡'}
            </button>
            <div class="dest-card-media-bottom">
              <span class="dest-card-region">${dest.country} · ${dest.region}</span>
              <span class="dest-card-temp">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                ${dest.temp}
              </span>
            </div>
          </div>
          <div class="dest-card-body">
            <div class="dest-card-header">
              <h3 class="dest-card-name">${dest.name}</h3>
              <div class="dest-card-rating">
                <span>★</span>
                <span>${dest.rating}</span>
              </div>
            </div>
            <div class="dest-card-tagline">"${dest.vibe}"</div>
            <p class="dest-card-desc">${dest.tagline}</p>
            <div class="dest-card-footer">
              <div class="dest-card-price">
                <span class="dest-card-price-label">Est. Daily</span>
                <span class="dest-card-price-val">$${dest.dailyBudget} <span>/ day</span></span>
              </div>
              <button class="dest-card-inspect-btn" data-inspect-id="${dest.id}">
                Inspect ↗
              </button>
            </div>
          </div>
        </article>
      `;
      })
      .join('');

    // Rebind spotlight & 3D tilt
    if (window.setupReactiveCards) {
      window.setupReactiveCards();
    }
  }

  // Update sliding pill for category tabs
  function updateCategoryPill() {
    categoryTabs.forEach((tab) => {
      const isCurrent = tab.dataset.category === currentCategory;
      tab.classList.toggle('active', isCurrent);
      if (isCurrent && categoryTabPill) {
        categoryTabPill.style.left = `${tab.offsetLeft}px`;
        categoryTabPill.style.width = `${tab.offsetWidth}px`;
      }
    });
  }

  // Category Tab clicks
  categoryTabs.forEach((tab) => {
    tab.addEventListener('click', (e) => {
      currentCategory = tab.dataset.category;
      updateCategoryPill();
      renderDestinations();
      if (window.burstSparks) {
        window.burstSparks(e.clientX, e.clientY, 8);
      }
    });
  });

  // Search input
  destinationSearchInput?.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderDestinations();
  });

  // Sort dropdown
  sortSelect?.addEventListener('change', (e) => {
    currentSort = e.target.value;
    renderDestinations();
  });

  // Quick chips in hero
  document.querySelectorAll('.quick-chip').forEach((chip) => {
    chip.addEventListener('click', (e) => {
      const tag = chip.dataset.query;
      if (tag) {
        searchQuery = tag;
        if (destinationSearchInput) destinationSearchInput.value = tag;
        currentCategory = 'all';
        updateCategoryPill();
        renderDestinations();
        if (window.navigateToChapter) {
          window.navigateToChapter('chapter-atlas', true);
        }
        if (window.burstSparks) {
          window.burstSparks(e.clientX, e.clientY, 12);
        }
      }
    });
  });

  // Smart Search Bar in Hero Form Submit
  const smartSearchForm = document.getElementById('smartSearchForm');
  smartSearchForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const destInput = document.getElementById('heroSearchDestination')?.value || '';
    const vibeSelect = document.getElementById('heroSearchVibe')?.value || 'all';

    searchQuery = destInput;
    currentCategory = vibeSelect;
    if (destinationSearchInput) destinationSearchInput.value = destInput;
    updateCategoryPill();
    renderDestinations();

    if (window.navigateToChapter) {
      window.navigateToChapter('chapter-atlas', true);
    }
  });

  /* ------------------------------------------------------------------------
     6. Wishlist Management (Save / Drawer)
     ------------------------------------------------------------------------ */
  const wishlistDrawerBackdrop = document.getElementById('wishlistDrawerBackdrop');
  const wishlistToggleBtn = document.getElementById('wishlistToggleBtn');
  const drawerCloseBtn = document.getElementById('drawerCloseBtn');
  const drawerBody = document.getElementById('drawerBody');
  const wishlistBadge = document.getElementById('wishlistBadge');
  const drawerPlanSavedBtn = document.getElementById('drawerPlanSavedBtn');

  function updateWishlistBadge() {
    if (!wishlistBadge) return;
    const count = savedDestinations.length;
    wishlistBadge.textContent = count;
    wishlistBadge.classList.add('bump');
    setTimeout(() => wishlistBadge.classList.remove('bump'), 400);
  }

  function renderWishlistDrawer() {
    if (!drawerBody || typeof DESTINATIONS === 'undefined') return;

    if (savedDestinations.length === 0) {
      drawerBody.innerHTML = `
        <div style="text-align:center;padding:3rem 1rem;color:var(--text-muted);">
          <div style="font-size:2.5rem;margin-bottom:0.5rem;">♡</div>
          <h4 style="font-size:1.1rem;margin-bottom:0.4rem;color:var(--text-main);">Your Wishlist is Empty</h4>
          <p style="font-size:0.85rem;">Click the heart icon on any destination card to save it for your next adventure.</p>
        </div>
      `;
      if (drawerPlanSavedBtn) drawerPlanSavedBtn.disabled = true;
      return;
    }

    if (drawerPlanSavedBtn) drawerPlanSavedBtn.disabled = false;

    const savedItems = DESTINATIONS.filter((d) => savedDestinations.includes(d.id));
    drawerBody.innerHTML = savedItems
      .map(
        (item) => `
        <div class="drawer-item">
          <img src="${item.image}" alt="${item.name}" />
          <div class="drawer-item-info">
            <div class="drawer-item-title">${item.name}</div>
            <div class="drawer-item-country">${item.country} · $${item.dailyBudget}/day</div>
          </div>
          <button class="drawer-remove-btn" data-remove-id="${item.id}" aria-label="Remove ${item.name}">✕</button>
        </div>
      `
      )
      .join('');
  }

  function toggleWishlist(destId, clickEvent) {
    const dest = DESTINATIONS.find((d) => d.id === destId);
    if (!dest) return;

    if (savedDestinations.includes(destId)) {
      savedDestinations = savedDestinations.filter((id) => id !== destId);
      showToast(`Removed ${dest.name} from your wishlist`);
    } else {
      savedDestinations.push(destId);
      showToast(`Added ${dest.name} to your wishlist!`, '♥');
      if (clickEvent && window.burstSparks) {
        window.burstSparks(clickEvent.clientX, clickEvent.clientY, 16);
      }
    }

    localStorage.setItem(STORAGE_KEY_SAVED, JSON.stringify(savedDestinations));
    updateWishlistBadge();
    renderDestinations();
    renderWishlistDrawer();
  }

  // Open/Close Wishlist Drawer
  wishlistToggleBtn?.addEventListener('click', () => {
    renderWishlistDrawer();
    wishlistDrawerBackdrop?.classList.add('is-active');
  });

  drawerCloseBtn?.addEventListener('click', () => {
    wishlistDrawerBackdrop?.classList.remove('is-active');
  });

  wishlistDrawerBackdrop?.addEventListener('click', (e) => {
    if (e.target === wishlistDrawerBackdrop) {
      wishlistDrawerBackdrop.classList.remove('is-active');
    }
  });

  // Remove from drawer click
  drawerBody?.addEventListener('click', (e) => {
    const removeBtn = e.target.closest('[data-remove-id]');
    if (removeBtn) {
      const id = removeBtn.dataset.removeId;
      toggleWishlist(id);
    }
  });

  // Plan with saved places
  drawerPlanSavedBtn?.addEventListener('click', () => {
    wishlistDrawerBackdrop?.classList.remove('is-active');
    if (savedDestinations.length > 0) {
      const firstSaved = savedDestinations[0];
      const select = document.getElementById('architectDestinationSelect');
      if (select) {
        select.value = firstSaved;
        select.dispatchEvent(new Event('change'));
      }
    }
    if (window.navigateToChapter) {
      window.navigateToChapter('chapter-architect', true);
    }
  });

  /* ------------------------------------------------------------------------
     7. Destination Inspection Modal (Detailed Telemetry Sheet)
     ------------------------------------------------------------------------ */
  const destinationModalBackdrop = document.getElementById('destinationModalBackdrop');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalSheetContent = document.getElementById('modalSheetContent');

  function openDestinationModal(destId) {
    const dest = DESTINATIONS.find((d) => d.id === destId);
    if (!dest || !modalSheetContent) return;

    const isSaved = savedDestinations.includes(dest.id);

    modalSheetContent.innerHTML = `
      <div class="modal-hero">
        <img src="${dest.image}" alt="${dest.name}" />
        <div class="modal-hero-overlay"></div>
        <div class="modal-hero-caption">
          <span class="chapter-badge" style="background:rgba(255,255,255,0.2);color:white;border:1px solid rgba(255,255,255,0.3);">${dest.category}</span>
          <h2 style="font-size:2.2rem;font-weight:800;letter-spacing:-0.03em;">${dest.name}, ${dest.country}</h2>
          <p style="color:#e2e8f0;font-size:0.95rem;">${dest.coords}</p>
        </div>
      </div>
      <div class="modal-body">
        <div class="modal-specs-bar">
          <div class="modal-spec-cell">
            <small>Best Season</small>
            <strong>${dest.season}</strong>
          </div>
          <div class="modal-spec-cell">
            <small>Avg Temp</small>
            <strong>${dest.temp}</strong>
          </div>
          <div class="modal-spec-cell">
            <small>Est. Daily</small>
            <strong>$${dest.dailyBudget} / day</strong>
          </div>
          <div class="modal-spec-cell">
            <small>Rating</small>
            <strong style="color:var(--accent-gold);">★ ${dest.rating} (${dest.reviews})</strong>
          </div>
        </div>

        <h4 style="font-size:1.15rem;margin-bottom:0.5rem;font-weight:700;">About this journey</h4>
        <p style="color:var(--text-muted);line-height:1.7;margin-bottom:1.5rem;">${dest.description}</p>

        <h4 style="font-size:1.15rem;margin-bottom:0.75rem;font-weight:700;">Curated Signature Experiences</h4>
        <div class="modal-highlights-list">
          ${dest.highlights
            .map(
              (h) => `
            <div class="modal-highlight-item">
              <span style="color:var(--g-green);font-size:1.2rem;font-weight:bold;">✓</span>
              <span>${h}</span>
            </div>
          `
            )
            .join('')}
        </div>

        <div style="display:flex;gap:1rem;margin-top:2rem;flex-wrap:wrap;">
          <button class="btn btn-primary" id="modalPlanJourneyBtn" data-plan-id="${dest.id}">
            Start Planning This Journey ↗
          </button>
          <button class="btn btn-outline" id="modalSaveWishlistBtn" data-save-id="${dest.id}">
            ${isSaved ? '♥ Wishlisted' : '♡ Add to Wishlist'}
          </button>
        </div>
      </div>
    `;

    destinationModalBackdrop?.classList.add('is-active');

    // Modal action handlers
    document.getElementById('modalSaveWishlistBtn')?.addEventListener('click', (e) => {
      toggleWishlist(dest.id, e);
      const btn = e.currentTarget;
      const nowSaved = savedDestinations.includes(dest.id);
      btn.textContent = nowSaved ? '♥ Wishlisted' : '♡ Add to Wishlist';
    });

    document.getElementById('modalPlanJourneyBtn')?.addEventListener('click', () => {
      destinationModalBackdrop?.classList.remove('is-active');
      const select = document.getElementById('architectDestinationSelect');
      if (select) {
        select.value = dest.id;
        select.dispatchEvent(new Event('change'));
      }
      if (window.navigateToChapter) {
        window.navigateToChapter('chapter-architect', true);
      }
    });
  }

  // Delegated card clicks
  document.addEventListener('click', (e) => {
    // Save button click
    const saveBtn = e.target.closest('.dest-card-save-btn');
    if (saveBtn) {
      e.stopPropagation();
      const id = saveBtn.dataset.saveId;
      toggleWishlist(id, e);
      return;
    }

    // Inspect button click or card body click
    const inspectBtn = e.target.closest('[data-inspect-id]');
    if (inspectBtn) {
      e.stopPropagation();
      openDestinationModal(inspectBtn.dataset.inspectId);
      return;
    }

    const card = e.target.closest('.dest-card');
    if (card && !e.target.closest('button')) {
      openDestinationModal(card.dataset.id);
    }
  });

  modalCloseBtn?.addEventListener('click', () => {
    destinationModalBackdrop?.classList.remove('is-active');
  });

  destinationModalBackdrop?.addEventListener('click', (e) => {
    if (e.target === destinationModalBackdrop) {
      destinationModalBackdrop.classList.remove('is-active');
    }
  });

  // ESC key closes modals/drawers
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      destinationModalBackdrop?.classList.remove('is-active');
      wishlistDrawerBackdrop?.classList.remove('is-active');
    }
  });

  /* ------------------------------------------------------------------------
     8. Trip Architect (Interactive Live Calculator)
     ------------------------------------------------------------------------ */
  const architectSelect = document.getElementById('architectDestinationSelect');
  const durationSlider = document.getElementById('architectDurationSlider');
  const durationDisplay = document.getElementById('architectDurationVal');
  const travellersInput = document.getElementById('architectTravellersInput');
  const styleLabels = Array.from(document.querySelectorAll('.style-radio-label'));
  const tripForm = document.getElementById('tripArchitectForm');

  // Preview elements
  const previewDestTitle = document.getElementById('previewDestTitle');
  const previewTotalCost = document.getElementById('previewTotalCost');
  const previewDailyRate = document.getElementById('previewDailyRate');
  const previewSeason = document.getElementById('previewSeason');
  const previewHighlights = document.getElementById('previewHighlights');

  let selectedStyleMultiplier = 1.0;

  // Populate Destination Select dropdown
  if (architectSelect && typeof DESTINATIONS !== 'undefined') {
    architectSelect.innerHTML = DESTINATIONS.map(
      (d) => `<option value="${d.id}">${d.name}, ${d.country} ($${d.dailyBudget}/day)</option>`
    ).join('');
  }

  function updateArchitectPreview() {
    if (!architectSelect || typeof DESTINATIONS === 'undefined') return;

    const destId = architectSelect.value;
    const dest = DESTINATIONS.find((d) => d.id === destId) || DESTINATIONS[0];
    const days = parseInt(durationSlider?.value || 7, 10);
    const travellers = parseInt(travellersInput?.value || 2, 10);

    if (durationDisplay) durationDisplay.textContent = `${days} Days`;

    const adjustedDailyRate = Math.round(dest.dailyBudget * selectedStyleMultiplier);
    const totalEstimate = adjustedDailyRate * days * travellers;

    if (previewDestTitle) previewDestTitle.textContent = `${dest.name}, ${dest.country}`;
    if (previewTotalCost) previewTotalCost.textContent = `$${totalEstimate.toLocaleString()}`;
    if (previewDailyRate) previewDailyRate.textContent = `$${adjustedDailyRate} / person`;
    if (previewSeason) previewSeason.textContent = dest.season;

    if (previewHighlights) {
      previewHighlights.innerHTML = dest.highlights
        .map(
          (h) => `
        <li class="itinerary-curated-item">
          <span class="itinerary-check-icon">✓</span>
          <span>${h}</span>
        </li>
      `
        )
        .join('');
    }
  }

  // Event Listeners for Architect
  architectSelect?.addEventListener('change', updateArchitectPreview);
  durationSlider?.addEventListener('input', updateArchitectPreview);
  travellersInput?.addEventListener('input', updateArchitectPreview);

  styleLabels.forEach((label) => {
    label.addEventListener('click', () => {
      styleLabels.forEach((l) => l.classList.remove('is-selected'));
      label.classList.add('is-selected');
      const radio = label.querySelector('input[type="radio"]');
      if (radio) {
        radio.checked = true;
        selectedStyleMultiplier = parseFloat(radio.value || 1.0);
      }
      updateArchitectPreview();
    });
  });

  // Save Trip Plan Submit
  tripForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const destId = architectSelect.value;
    const dest = DESTINATIONS.find((d) => d.id === destId);
    const days = parseInt(durationSlider.value, 10);
    const travellers = parseInt(travellersInput.value, 10);

    const tripRecord = {
      id: 'trip_' + Date.now(),
      destination: dest.name,
      country: dest.country,
      days,
      travellers,
      multiplier: selectedStyleMultiplier,
      createdAt: new Date().toISOString()
    };

    const savedTrips = JSON.parse(localStorage.getItem(STORAGE_KEY_TRIPS) || '[]');
    savedTrips.push(tripRecord);
    localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(savedTrips));

    showToast(`Trip snapshot for ${dest.name} saved!`, '🎉');
    if (window.burstSparks) {
      const rect = e.target.querySelector('button[type="submit"]').getBoundingClientRect();
      window.burstSparks(rect.left + rect.width / 2, rect.top + rect.height / 2, 28);
    }
  });

  /* ------------------------------------------------------------------------
     9. Interactive FAQ Accordion
     ------------------------------------------------------------------------ */
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach((item) => {
    const btn = item.querySelector('.faq-question-btn');
    btn?.addEventListener('click', () => {
      const isOpen = item.classList.contains('is-open');
      faqItems.forEach((other) => other.classList.remove('is-open'));
      if (!isOpen) {
        item.classList.add('is-open');
      }
    });
  });

  /* ------------------------------------------------------------------------
     10. Initialization
     ------------------------------------------------------------------------ */
  renderDestinations();
  updateCategoryPill();
  updateWishlistBadge();
  updateArchitectPreview();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
